package com.auto.hotspot.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.auto.hotspot.R;
import com.auto.hotspot.database.DatabaseHelper;
import com.auto.hotspot.services.HotspotService;

public class SetupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences("AutoHotspot", MODE_PRIVATE);
        boolean setupDone = prefs.getBoolean("setup_done", false);

        // Si ya hay coches configurados, ir directamente al main
        if (setupDone && !DatabaseHelper.getInstance(this).getAllCars().isEmpty()) {
            goToMain();
            return;
        }

        setContentView(R.layout.activity_setup);

        TextView tvTitle = findViewById(R.id.tvSetupTitle);
        tvTitle.setText("👋 Bienvenido a\nAuto Hotspot");

        Button btnStart = findViewById(R.id.btnStartSetup);
        btnStart.setOnClickListener(v -> {
            Intent i = new Intent(this, AddCarActivity.class);
            i.putExtra("first_setup", true);
            startActivity(i);
            finish();
        });
    }

    private void goToMain() {
        // Iniciar servicio en segundo plano
        Intent svc = new Intent(this, HotspotService.class);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
