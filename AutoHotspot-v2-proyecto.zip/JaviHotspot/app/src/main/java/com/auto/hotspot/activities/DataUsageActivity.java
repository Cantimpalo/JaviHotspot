package com.auto.hotspot.activities;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.auto.hotspot.R;
import com.auto.hotspot.database.DatabaseHelper;
import com.auto.hotspot.models.Car;
import com.auto.hotspot.models.DataSession;
import com.auto.hotspot.utils.DataUtils;

import java.util.Calendar;
import java.util.List;

public class DataUsageActivity extends AppCompatActivity {

    private Spinner spinnerCar;
    private TextView tvSummary, tvRangeResult;
    private Button btnQueryRange, btnDeleteData;
    private TextView tvDateFrom, tvDateTo;

    private DatabaseHelper db;
    private List<Car> cars;
    private long dateFromMs = 0;
    private long dateToMs = Long.MAX_VALUE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_usage);

        db = DatabaseHelper.getInstance(this);

        spinnerCar    = findViewById(R.id.spinnerCar);
        tvSummary     = findViewById(R.id.tvSummary);
        tvRangeResult = findViewById(R.id.tvRangeResult);
        btnQueryRange = findViewById(R.id.btnQueryRange);
        btnDeleteData = findViewById(R.id.btnDeleteData);
        tvDateFrom    = findViewById(R.id.tvDateFrom);
        tvDateTo      = findViewById(R.id.tvDateTo);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("📊 Uso de datos");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Fechas por defecto: último mes
        Calendar cal = Calendar.getInstance();
        dateToMs = cal.getTimeInMillis();
        cal.add(Calendar.MONTH, -1);
        dateFromMs = cal.getTimeInMillis();
        tvDateFrom.setText(DataUtils.formatDateShort(dateFromMs));
        tvDateTo.setText(DataUtils.formatDateShort(dateToMs));

        tvDateFrom.setOnClickListener(v -> pickDate(true));
        tvDateTo.setOnClickListener(v -> pickDate(false));

        loadCarSpinner();

        spinnerCar.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                showCarSummary(cars.get(pos));
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        btnQueryRange.setOnClickListener(v -> {
            if (!cars.isEmpty()) queryRange(cars.get(spinnerCar.getSelectedItemPosition()));
        });

        btnDeleteData.setOnClickListener(v -> {
            if (!cars.isEmpty()) askDeleteOptions(cars.get(spinnerCar.getSelectedItemPosition()));
        });

        // Si viene con car_id preseleccionado
        int preselect = getIntent().getIntExtra("car_id", -1);
        if (preselect > 0) {
            for (int i = 0; i < cars.size(); i++) {
                if (cars.get(i).getId() == preselect) {
                    spinnerCar.setSelection(i);
                    break;
                }
            }
        }
    }

    private void loadCarSpinner() {
        cars = db.getAllCars();
        String[] names = new String[cars.size()];
        for (int i = 0; i < cars.size(); i++) names[i] = cars.get(i).getDisplayName();
        ArrayAdapter<String> a = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, names);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCar.setAdapter(a);
        if (!cars.isEmpty()) showCarSummary(cars.get(0));
    }

    private void showCarSummary(Car car) {
        List<DataSession> sessions = db.getSessionsForCar(car.getId());
        long totalDown = 0, totalUp = 0, totalTime = 0;
        for (DataSession s : sessions) {
            totalDown += s.getBytesDownloaded();
            totalUp   += s.getBytesUploaded();
            totalTime += s.getDurationMs();
        }

        StringBuilder sb = new StringBuilder();
        sb.append("🚗  ").append(car.getCarBrand()).append(" ").append(car.getCarModel()).append("\n");
        sb.append("👤  ").append(car.getOwnerName()).append("\n\n");
        sb.append("📋  Sesiones registradas: ").append(sessions.size()).append("\n");
        sb.append("⏱  Tiempo total conectado: ").append(DataUtils.formatDuration(totalTime)).append("\n");
        sb.append("⬇  Total descargado: ").append(DataUtils.formatBytes(totalDown)).append("\n");
        sb.append("⬆  Total subido: ").append(DataUtils.formatBytes(totalUp)).append("\n");
        sb.append("📦  Total consumido: ").append(DataUtils.formatBytes(totalDown + totalUp)).append("\n\n");

        // Últimas 5 sesiones
        sb.append("─────── Últimas sesiones ───────\n");
        int limit = Math.min(5, sessions.size());
        for (int i = 0; i < limit; i++) {
            DataSession s = sessions.get(i);
            sb.append("• ").append(DataUtils.formatDate(s.getStartTime()))
              .append("  →  ").append(DataUtils.formatBytes(s.getTotalBytes()))
              .append(" (").append(DataUtils.formatDuration(s.getDurationMs())).append(")\n");
        }

        tvSummary.setText(sb.toString());
        tvRangeResult.setText("");
    }

    private void queryRange(Car car) {
        // Ajustar dateToMs al final del día seleccionado
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(dateToMs);
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        long toEnd = cal.getTimeInMillis();

        List<DataSession> sessions = db.getSessionsForCarInRange(car.getId(), dateFromMs, toEnd);
        long totalDown = 0, totalUp = 0, totalTime = 0;
        for (DataSession s : sessions) {
            totalDown += s.getBytesDownloaded();
            totalUp   += s.getBytesUploaded();
            totalTime += s.getDurationMs();
        }

        String result = "📅 Del " + DataUtils.formatDateShort(dateFromMs) +
                " al " + DataUtils.formatDateShort(toEnd) + "\n\n" +
                "Sesiones: " + sessions.size() + "\n" +
                "⏱ Duración: " + DataUtils.formatDuration(totalTime) + "\n" +
                "⬇ Descarga: " + DataUtils.formatBytes(totalDown) + "\n" +
                "⬆ Subida: " + DataUtils.formatBytes(totalUp) + "\n" +
                "📦 Total: " + DataUtils.formatBytes(totalDown + totalUp);

        tvRangeResult.setText(result);
    }

    private void askDeleteOptions(Car car) {
        new AlertDialog.Builder(this, R.style.Dialog_Dark)
                .setTitle("🗑  Borrar datos — " + car.getCarBrand() + " " + car.getCarModel())
                .setMessage("¿Qué deseas borrar?")
                .setPositiveButton("🗓 Borrado parcial (por fechas)", (d, w) -> requestPinForDelete(car, false))
                .setNegativeButton("🗑 Borrado total", (d, w) -> requestPinForDelete(car, true))
                .setNeutralButton("Cancelar", null)
                .show();
    }

    private void requestPinForDelete(Car car, boolean total) {
        Intent i = new Intent(this, PinActivity.class);
        i.putExtra("pin", car.getPin());
        i.putExtra("action", total ? "delete_total" : "delete_partial");
        i.putExtra("car_id", car.getId());
        startActivityForResult(i, total ? 300 : 301);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK) return;

        int carId = data.getIntExtra("car_id", -1);
        Car car = db.getCarById(carId);
        if (car == null) return;

        if (req == 300) {
            // Borrado total confirmado
            db.deleteSessionsForCar(carId);
            Toast.makeText(this, "✅ Todos los datos borrados", Toast.LENGTH_SHORT).show();
            showCarSummary(car);

        } else if (req == 301) {
            // Borrado parcial: pedir fechas
            showPartialDeleteDialog(car);
        }
    }

    private void showPartialDeleteDialog(Car car) {
        View v = getLayoutInflater().inflate(R.layout.dialog_date_range, null);
        TextView tvFrom = v.findViewById(R.id.tvDialogFrom);
        TextView tvTo   = v.findViewById(R.id.tvDialogTo);

        final long[] fromMs = {dateFromMs};
        final long[] toMs   = {dateToMs};

        tvFrom.setText(DataUtils.formatDateShort(fromMs[0]));
        tvTo.setText(DataUtils.formatDateShort(toMs[0]));

        tvFrom.setOnClickListener(x -> {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(fromMs[0]);
            new DatePickerDialog(this, (dp, y, m, d) -> {
                c.set(y, m, d, 0, 0, 0);
                fromMs[0] = c.getTimeInMillis();
                tvFrom.setText(DataUtils.formatDateShort(fromMs[0]));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        tvTo.setOnClickListener(x -> {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(toMs[0]);
            new DatePickerDialog(this, (dp, y, m, d) -> {
                c.set(y, m, d, 23, 59, 59);
                toMs[0] = c.getTimeInMillis();
                tvTo.setText(DataUtils.formatDateShort(toMs[0]));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        new AlertDialog.Builder(this, R.style.Dialog_Dark)
                .setTitle("📅 Selecciona rango a borrar")
                .setView(v)
                .setPositiveButton("🗑 Borrar", (d, w) -> {
                    db.deleteSessionsInRange(car.getId(), fromMs[0], toMs[0]);
                    Toast.makeText(this, "✅ Datos del rango borrados", Toast.LENGTH_SHORT).show();
                    showCarSummary(db.getCarById(car.getId()));
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void pickDate(boolean isFrom) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(isFrom ? dateFromMs : dateToMs);
        new DatePickerDialog(this, (dp, y, m, d) -> {
            cal.set(y, m, d, isFrom ? 0 : 23, isFrom ? 0 : 59, isFrom ? 0 : 59);
            if (isFrom) {
                dateFromMs = cal.getTimeInMillis();
                tvDateFrom.setText(DataUtils.formatDateShort(dateFromMs));
            } else {
                dateToMs = cal.getTimeInMillis();
                tvDateTo.setText(DataUtils.formatDateShort(dateToMs));
            }
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
