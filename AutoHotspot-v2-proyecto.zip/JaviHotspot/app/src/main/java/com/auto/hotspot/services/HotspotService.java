package com.auto.hotspot.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.TetheringManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.auto.hotspot.R;
import com.auto.hotspot.activities.MainActivity;
import com.auto.hotspot.database.DatabaseHelper;
import com.auto.hotspot.models.Car;
import com.auto.hotspot.models.DataSession;
import com.auto.hotspot.utils.DataUtils;

import java.lang.reflect.Method;

public class HotspotService extends Service {

    private static final String TAG = "AutoHotspot";
    public static final String CHANNEL_ID = "AutoHotspotChannel";
    public static final int NOTIF_ID = 1;

    // Acciones para comunicación interna
    public static final String ACTION_CAR_CONNECTED = "com.auto.hotspot.CAR_CONNECTED";
    public static final String ACTION_CAR_DISCONNECTED = "com.auto.hotspot.CAR_DISCONNECTED";
    public static final String EXTRA_CAR_ID = "car_id";

    private DatabaseHelper db;
    private BluetoothAdapter btAdapter;
    private boolean hotspotActive = false;

    // Sesión actual
    private int currentSessionId = -1;
    private int currentCarId = -1;
    private long sessionStartRxBytes = 0;
    private long sessionStartTxBytes = 0;

    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null) return;

            BluetoothDevice device = getDeviceFromIntent(intent);
            if (device == null && !BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) return;

            switch (action) {
                case BluetoothDevice.ACTION_ACL_CONNECTED:
                    if (device != null) handleDeviceConnected(device.getAddress());
                    break;
                case BluetoothDevice.ACTION_ACL_DISCONNECTED:
                    if (device != null) handleDeviceDisconnected(device.getAddress());
                    break;
                case BluetoothAdapter.ACTION_STATE_CHANGED:
                    int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1);
                    if (state == BluetoothAdapter.STATE_ON) checkConnectedDevices();
                    break;
            }
        }
    };

    @SuppressWarnings("deprecation")
    private BluetoothDevice getDeviceFromIntent(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
        } else {
            return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        db = DatabaseHelper.getInstance(this);
        btAdapter = BluetoothAdapter.getDefaultAdapter();

        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification("🔍 Esperando conexión al coche..."));

        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(btReceiver, filter);

        checkConnectedDevices();
        Log.d(TAG, "HotspotService iniciado");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(btReceiver); } catch (Exception ignored) {}
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ===== LÓGICA PRINCIPAL =====

    private void handleDeviceConnected(String address) {
        Car car = db.getCarByBtAddress(address);
        if (car == null) return;

        Log.d(TAG, "Coche conectado: " + car.getDisplayName());
        currentCarId = car.getId();

        // Iniciar sesión de datos
        sessionStartRxBytes = DataUtils.getTotalRxBytes();
        sessionStartTxBytes = DataUtils.getTotalTxBytes();
        currentSessionId = (int) db.startSession(car.getId());

        enableHotspot();
        updateNotification("🚗 " + car.getCarBrand() + " " + car.getCarModel() + " conectado — Hotspot activo");

        // Notificar a la actividad
        Intent broadcast = new Intent(ACTION_CAR_CONNECTED);
        broadcast.putExtra(EXTRA_CAR_ID, car.getId());
        sendBroadcast(broadcast);
    }

    private void handleDeviceDisconnected(String address) {
        Car car = db.getCarByBtAddress(address);
        if (car == null || car.getId() != currentCarId) return;

        Log.d(TAG, "Coche desconectado: " + car.getDisplayName());

        // Cerrar sesión y guardar datos
        if (currentSessionId > 0) {
            long rxEnd = DataUtils.getTotalRxBytes();
            long txEnd = DataUtils.getTotalTxBytes();
            long down = Math.max(0, rxEnd - sessionStartRxBytes);
            long up = Math.max(0, txEnd - sessionStartTxBytes);
            db.endSession(currentSessionId, down, up);
            db.updateCarBytes(currentCarId, down + up);
        }

        int disconnectedCarId = currentCarId;
        currentCarId = -1;
        currentSessionId = -1;

        disableHotspot();
        updateNotification("🔍 Esperando conexión al coche...");

        // Notificar desconexión
        Intent broadcast = new Intent(ACTION_CAR_DISCONNECTED);
        broadcast.putExtra(EXTRA_CAR_ID, disconnectedCarId);
        sendBroadcast(broadcast);
    }

    private void checkConnectedDevices() {
        if (btAdapter == null || !btAdapter.isEnabled()) return;
        try {
            btAdapter.getProfileProxy(this, new BluetoothProfile.ServiceListener() {
                @Override
                public void onServiceConnected(int profile, BluetoothProfile proxy) {
                    for (BluetoothDevice dev : proxy.getConnectedDevices()) {
                        Car car = db.getCarByBtAddress(dev.getAddress());
                        if (car != null && currentCarId == -1) {
                            handleDeviceConnected(dev.getAddress());
                            break;
                        }
                    }
                    btAdapter.closeProfileProxy(profile, proxy);
                }
                @Override
                public void onServiceDisconnected(int profile) {}
            }, BluetoothProfile.HEADSET);
        } catch (Exception e) {
            Log.e(TAG, "Error checkConnectedDevices: " + e.getMessage());
        }
    }

    // ===== HOTSPOT =====

    private void enableHotspot() {
        if (hotspotActive) return;
        if (tryTetheringManager(true)) return;
        tryReflection(true);
    }

    private void disableHotspot() {
        if (!hotspotActive) return;
        if (tryTetheringManager(false)) return;
        tryReflection(false);
    }

    private boolean tryTetheringManager(boolean enable) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false;
        try {
            TetheringManager tm = (TetheringManager) getSystemService(Context.TETHERING_SERVICE);
            if (tm == null) return false;
            if (enable) {
                TetheringManager.TetheringRequest req =
                        new TetheringManager.TetheringRequest.Builder(TetheringManager.TETHERING_WIFI).build();
                tm.startTethering(req, getMainExecutor(), new TetheringManager.StartTetheringCallback() {
                    @Override
                    public void onTetheringStarted() {
                        hotspotActive = true;
                        Log.d(TAG, "Hotspot activado (TetheringManager)");
                    }
                    @Override
                    public void onTetheringFailed(int error) {
                        Log.e(TAG, "TetheringManager error: " + error);
                    }
                });
            } else {
                tm.stopTethering(TetheringManager.TETHERING_WIFI);
                hotspotActive = false;
                Log.d(TAG, "Hotspot desactivado (TetheringManager)");
            }
            return true;
        } catch (Exception e) {
            Log.e(TAG, "TetheringManager exception: " + e.getMessage());
            return false;
        }
    }

    private void tryReflection(boolean enable) {
        try {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi == null) return;
            Method method = wifi.getClass().getDeclaredMethod("setWifiApEnabled",
                    android.net.wifi.WifiConfiguration.class, boolean.class);
            method.setAccessible(true);
            method.invoke(wifi, null, enable);
            hotspotActive = enable;
            Log.d(TAG, "Hotspot " + (enable ? "activado" : "desactivado") + " (reflection)");
        } catch (Exception e) {
            Log.e(TAG, "Reflection error: " + e.getMessage());
        }
    }

    // ===== NOTIFICACIONES =====

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Auto Hotspot", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String text) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Auto Hotspot")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pi)
                .setOngoing(true)
                .setSilent(true)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification(text));
    }
}
