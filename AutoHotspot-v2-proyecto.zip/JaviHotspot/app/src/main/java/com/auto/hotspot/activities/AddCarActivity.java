package com.auto.hotspot.activities;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.auto.hotspot.R;
import com.auto.hotspot.database.DatabaseHelper;
import com.auto.hotspot.models.Car;
import com.auto.hotspot.services.HotspotService;
import com.auto.hotspot.utils.CarBrands;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class AddCarActivity extends AppCompatActivity {

    private static final int PERM_CODE = 101;

    private EditText etOwnerName, etCarModel, etPin, etPinConfirm;
    private Spinner spinnerBrand, spinnerBtDevice;
    private Button btnSave;
    private TextView tvBrandIcon;

    private BluetoothAdapter btAdapter;
    private List<String> btNames = new ArrayList<>();
    private List<String> btAddresses = new ArrayList<>();
    private boolean isFirstSetup = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_car);

        isFirstSetup = getIntent().getBooleanExtra("first_setup", false);
        btAdapter = BluetoothAdapter.getDefaultAdapter();

        etOwnerName    = findViewById(R.id.etOwnerName);
        etCarModel     = findViewById(R.id.etCarModel);
        etPin          = findViewById(R.id.etPin);
        etPinConfirm   = findViewById(R.id.etPinConfirm);
        spinnerBrand   = findViewById(R.id.spinnerBrand);
        spinnerBtDevice = findViewById(R.id.spinnerBtDevice);
        btnSave        = findViewById(R.id.btnSaveCar);
        tvBrandIcon    = findViewById(R.id.tvBrandIcon);

        // Configurar spinner de marcas
        ArrayAdapter<String> brandAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, CarBrands.BRANDS);
        brandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerBrand.setAdapter(brandAdapter);

        spinnerBrand.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                tvBrandIcon.setText(CarBrands.BRAND_ICONS[pos]);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnSave.setOnClickListener(v -> saveCar());

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(isFirstSetup ? "Añadir mi primer coche" : "Añadir coche");
            getSupportActionBar().setDisplayHomeAsUpEnabled(!isFirstSetup);
        }

        requestPermissionsAndLoadBt();
    }

    private void requestPermissionsAndLoadBt() {
        List<String> needed = new ArrayList<>();
        needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            needed.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        List<String> toRequest = new ArrayList<>();
        for (String p : needed) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(p);
            }
        }
        if (!toRequest.isEmpty()) {
            ActivityCompat.requestPermissions(this, toRequest.toArray(new String[0]), PERM_CODE);
        } else {
            loadBluetoothDevices();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] grants) {
        super.onRequestPermissionsResult(code, perms, grants);
        loadBluetoothDevices();
    }

    private void loadBluetoothDevices() {
        btNames.clear();
        btAddresses.clear();

        if (btAdapter == null || !btAdapter.isEnabled()) {
            btNames.add("⚠ Activa el Bluetooth primero");
            btAddresses.add("");
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                        != PackageManager.PERMISSION_GRANTED) {
                btNames.add("⚠ Permiso Bluetooth denegado");
                btAddresses.add("");
            } else {
                Set<BluetoothDevice> paired = btAdapter.getBondedDevices();
                for (BluetoothDevice d : paired) {
                    String n = d.getName() != null ? d.getName() : "Desconocido";
                    btNames.add(n);
                    btAddresses.add(d.getAddress());
                }
                if (btNames.isEmpty()) {
                    btNames.add("No hay dispositivos emparejados");
                    btAddresses.add("");
                }
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, btNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerBtDevice.setAdapter(adapter);
    }

    private void saveCar() {
        String owner = etOwnerName.getText().toString().trim();
        String model = etCarModel.getText().toString().trim();
        String pin   = etPin.getText().toString().trim();
        String pin2  = etPinConfirm.getText().toString().trim();
        int brandPos = spinnerBrand.getSelectedItemPosition();
        int btPos    = spinnerBtDevice.getSelectedItemPosition();

        // Validaciones
        if (owner.isEmpty()) { etOwnerName.setError("Introduce tu nombre"); return; }
        if (model.isEmpty()) { etCarModel.setError("Introduce el modelo"); return; }
        if (pin.length() < 4) { etPin.setError("Mínimo 4 dígitos"); return; }
        if (!pin.equals(pin2)) { etPinConfirm.setError("Los PINs no coinciden"); return; }
        if (btAddresses.get(btPos).isEmpty()) {
            Toast.makeText(this, "Selecciona un dispositivo Bluetooth válido", Toast.LENGTH_SHORT).show();
            return;
        }

        String brand   = CarBrands.BRANDS[brandPos];
        String btAddr  = btAddresses.get(btPos);
        String btName  = btNames.get(btPos);

        Car car = new Car(owner, brand, model, btAddr, btName, pin);
        DatabaseHelper.getInstance(this).insertCar(car);

        // Marcar setup completo
        SharedPreferences prefs = getSharedPreferences("AutoHotspot", MODE_PRIVATE);
        prefs.edit().putBoolean("setup_done", true).apply();

        Toast.makeText(this, "✅ " + brand + " " + model + " añadido", Toast.LENGTH_SHORT).show();

        // Iniciar servicio
        Intent svc = new Intent(this, HotspotService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc);
        else startService(svc);

        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
