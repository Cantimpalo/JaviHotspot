package com.auto.hotspot.models;

public class DataSession {
    private int id;
    private int carId;
    private long startTime;
    private long endTime;
    private long bytesDownloaded;
    private long bytesUploaded;

    public DataSession() {}

    public DataSession(int carId, long startTime) {
        this.carId = carId;
        this.startTime = startTime;
        this.endTime = 0;
        this.bytesDownloaded = 0;
        this.bytesUploaded = 0;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getCarId() { return carId; }
    public void setCarId(int carId) { this.carId = carId; }
    public long getStartTime() { return startTime; }
    public void setStartTime(long startTime) { this.startTime = startTime; }
    public long getEndTime() { return endTime; }
    public void setEndTime(long endTime) { this.endTime = endTime; }
    public long getBytesDownloaded() { return bytesDownloaded; }
    public void setBytesDownloaded(long bytesDownloaded) { this.bytesDownloaded = bytesDownloaded; }
    public long getBytesUploaded() { return bytesUploaded; }
    public void setBytesUploaded(long bytesUploaded) { this.bytesUploaded = bytesUploaded; }

    public long getTotalBytes() {
        return bytesDownloaded + bytesUploaded;
    }

    public long getDurationMs() {
        if (endTime > 0) return endTime - startTime;
        return System.currentTimeMillis() - startTime;
    }
}
