package com.auto.hotspot.models;

public class Car {
    private int id;
    private String ownerName;
    private String carBrand;   // Tesla, BMW, Mercedes, etc.
    private String carModel;   // Model 3, Serie 5, etc.
    private String bluetoothAddress;
    private String bluetoothName;
    private String pin;
    private long totalBytesUsed;
    private long createdAt;

    public Car() {}

    public Car(String ownerName, String carBrand, String carModel,
               String bluetoothAddress, String bluetoothName, String pin) {
        this.ownerName = ownerName;
        this.carBrand = carBrand;
        this.carModel = carModel;
        this.bluetoothAddress = bluetoothAddress;
        this.bluetoothName = bluetoothName;
        this.pin = pin;
        this.totalBytesUsed = 0;
        this.createdAt = System.currentTimeMillis();
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    public String getCarBrand() { return carBrand; }
    public void setCarBrand(String carBrand) { this.carBrand = carBrand; }
    public String getCarModel() { return carModel; }
    public void setCarModel(String carModel) { this.carModel = carModel; }
    public String getBluetoothAddress() { return bluetoothAddress; }
    public void setBluetoothAddress(String bluetoothAddress) { this.bluetoothAddress = bluetoothAddress; }
    public String getBluetoothName() { return bluetoothName; }
    public void setBluetoothName(String bluetoothName) { this.bluetoothName = bluetoothName; }
    public String getPin() { return pin; }
    public void setPin(String pin) { this.pin = pin; }
    public long getTotalBytesUsed() { return totalBytesUsed; }
    public void setTotalBytesUsed(long totalBytesUsed) { this.totalBytesUsed = totalBytesUsed; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    public String getDisplayName() {
        return ownerName + " · " + carBrand + " " + carModel;
    }
}
