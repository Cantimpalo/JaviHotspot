package com.auto.hotspot.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class DataUtils {

    public static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format(Locale.getDefault(), "%.2f MB", bytes / (1024.0 * 1024));
        return String.format(Locale.getDefault(), "%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }

    public static String formatDuration(long ms) {
        long hours = TimeUnit.MILLISECONDS.toHours(ms);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(ms) % 60;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60;
        if (hours > 0) return String.format(Locale.getDefault(), "%dh %02dm %02ds", hours, minutes, seconds);
        if (minutes > 0) return String.format(Locale.getDefault(), "%dm %02ds", minutes, seconds);
        return String.format(Locale.getDefault(), "%ds", seconds);
    }

    public static String formatDate(long ms) {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date(ms));
    }

    public static String formatDateShort(long ms) {
        return new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date(ms));
    }

    /** Obtiene bytes recibidos del sistema desde el arranque */
    public static long getMobileRxBytes() {
        return android.net.TrafficStats.getMobileRxBytes();
    }

    public static long getMobileTxBytes() {
        return android.net.TrafficStats.getMobileTxBytes();
    }

    public static long getTotalRxBytes() {
        return android.net.TrafficStats.getTotalRxBytes();
    }

    public static long getTotalTxBytes() {
        return android.net.TrafficStats.getTotalTxBytes();
    }
}
