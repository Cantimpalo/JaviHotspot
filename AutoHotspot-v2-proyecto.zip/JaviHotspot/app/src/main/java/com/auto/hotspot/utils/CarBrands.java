package com.auto.hotspot.utils;

public class CarBrands {
    public static final String[] BRANDS = {
        "Tesla",
        "BMW",
        "Mercedes-Benz",
        "Audi",
        "Volkswagen",
        "Seat",
        "Kia",
        "Hyundai",
        "Toyota",
        "Ford",
        "Renault",
        "Peugeot",
        "Citroën",
        "Volvo",
        "Porsche",
        "Lexus",
        "Nissan",
        "Honda",
        "Mazda",
        "Skoda",
        "Opel",
        "Dacia",
        "Jeep",
        "Land Rover",
        "Subaru",
        "Otro"
    };

    // Emoji/símbolo representativo por marca (para el icono del spinner)
    public static final String[] BRAND_ICONS = {
        "⚡", // Tesla
        "🔵", // BMW
        "⭐", // Mercedes
        "💠", // Audi
        "🔷", // VW
        "🟡", // Seat
        "🦁", // Kia
        "🔶", // Hyundai
        "🏯", // Toyota
        "🔵", // Ford
        "🔷", // Renault
        "🦁", // Peugeot
        "🔑", // Citroën
        "🛡️", // Volvo
        "🏎️", // Porsche
        "👑", // Lexus
        "🍃", // Nissan
        "🟥", // Honda
        "🟠", // Mazda
        "✈️", // Skoda
        "⚡", // Opel
        "🏔️", // Dacia
        "🦅", // Jeep
        "🌿", // Land Rover
        "⭐", // Subaru
        "🚗"  // Otro
    };
}
