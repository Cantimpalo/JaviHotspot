package com.auto.hotspot.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.auto.hotspot.models.Car;
import com.auto.hotspot.models.DataSession;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "autohotspot.db";
    private static final int DB_VERSION = 1;

    // Tabla coches
    public static final String TABLE_CARS = "cars";
    public static final String COL_ID = "id";
    public static final String COL_OWNER = "owner_name";
    public static final String COL_BRAND = "car_brand";
    public static final String COL_MODEL = "car_model";
    public static final String COL_BT_ADDRESS = "bt_address";
    public static final String COL_BT_NAME = "bt_name";
    public static final String COL_PIN = "pin";
    public static final String COL_TOTAL_BYTES = "total_bytes";
    public static final String COL_CREATED = "created_at";

    // Tabla sesiones
    public static final String TABLE_SESSIONS = "sessions";
    public static final String COL_CAR_ID = "car_id";
    public static final String COL_START = "start_time";
    public static final String COL_END = "end_time";
    public static final String COL_BYTES_DOWN = "bytes_downloaded";
    public static final String COL_BYTES_UP = "bytes_uploaded";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context ctx) {
        if (instance == null) {
            instance = new DatabaseHelper(ctx.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_CARS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_OWNER + " TEXT, " +
                COL_BRAND + " TEXT, " +
                COL_MODEL + " TEXT, " +
                COL_BT_ADDRESS + " TEXT UNIQUE, " +
                COL_BT_NAME + " TEXT, " +
                COL_PIN + " TEXT, " +
                COL_TOTAL_BYTES + " INTEGER DEFAULT 0, " +
                COL_CREATED + " INTEGER)");

        db.execSQL("CREATE TABLE " + TABLE_SESSIONS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CAR_ID + " INTEGER, " +
                COL_START + " INTEGER, " +
                COL_END + " INTEGER DEFAULT 0, " +
                COL_BYTES_DOWN + " INTEGER DEFAULT 0, " +
                COL_BYTES_UP + " INTEGER DEFAULT 0, " +
                "FOREIGN KEY(" + COL_CAR_ID + ") REFERENCES " + TABLE_CARS + "(" + COL_ID + "))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SESSIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CARS);
        onCreate(db);
    }

    // ===== COCHES =====

    public long insertCar(Car car) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_OWNER, car.getOwnerName());
        cv.put(COL_BRAND, car.getCarBrand());
        cv.put(COL_MODEL, car.getCarModel());
        cv.put(COL_BT_ADDRESS, car.getBluetoothAddress());
        cv.put(COL_BT_NAME, car.getBluetoothName());
        cv.put(COL_PIN, car.getPin());
        cv.put(COL_TOTAL_BYTES, 0);
        cv.put(COL_CREATED, System.currentTimeMillis());
        return db.insert(TABLE_CARS, null, cv);
    }

    public List<Car> getAllCars() {
        List<Car> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_CARS, null, null, null, null, null, COL_OWNER + " ASC");
        while (c.moveToNext()) list.add(cursorToCar(c));
        c.close();
        return list;
    }

    public Car getCarByBtAddress(String address) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_CARS, null, COL_BT_ADDRESS + "=?", new String[]{address}, null, null, null);
        Car car = null;
        if (c.moveToFirst()) car = cursorToCar(c);
        c.close();
        return car;
    }

    public Car getCarById(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_CARS, null, COL_ID + "=?", new String[]{String.valueOf(id)}, null, null, null);
        Car car = null;
        if (c.moveToFirst()) car = cursorToCar(c);
        c.close();
        return car;
    }

    public void updateCarBytes(int carId, long extraBytes) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("UPDATE " + TABLE_CARS + " SET " + COL_TOTAL_BYTES + " = " +
                COL_TOTAL_BYTES + " + " + extraBytes + " WHERE " + COL_ID + " = " + carId);
    }

    public void deleteCar(int carId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_SESSIONS, COL_CAR_ID + "=?", new String[]{String.valueOf(carId)});
        db.delete(TABLE_CARS, COL_ID + "=?", new String[]{String.valueOf(carId)});
    }

    private Car cursorToCar(Cursor c) {
        Car car = new Car();
        car.setId(c.getInt(c.getColumnIndexOrThrow(COL_ID)));
        car.setOwnerName(c.getString(c.getColumnIndexOrThrow(COL_OWNER)));
        car.setCarBrand(c.getString(c.getColumnIndexOrThrow(COL_BRAND)));
        car.setCarModel(c.getString(c.getColumnIndexOrThrow(COL_MODEL)));
        car.setBluetoothAddress(c.getString(c.getColumnIndexOrThrow(COL_BT_ADDRESS)));
        car.setBluetoothName(c.getString(c.getColumnIndexOrThrow(COL_BT_NAME)));
        car.setPin(c.getString(c.getColumnIndexOrThrow(COL_PIN)));
        car.setTotalBytesUsed(c.getLong(c.getColumnIndexOrThrow(COL_TOTAL_BYTES)));
        car.setCreatedAt(c.getLong(c.getColumnIndexOrThrow(COL_CREATED)));
        return car;
    }

    // ===== SESIONES =====

    public long startSession(int carId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_CAR_ID, carId);
        cv.put(COL_START, System.currentTimeMillis());
        cv.put(COL_END, 0);
        cv.put(COL_BYTES_DOWN, 0);
        cv.put(COL_BYTES_UP, 0);
        return db.insert(TABLE_SESSIONS, null, cv);
    }

    public void endSession(int sessionId, long bytesDown, long bytesUp) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_END, System.currentTimeMillis());
        cv.put(COL_BYTES_DOWN, bytesDown);
        cv.put(COL_BYTES_UP, bytesUp);
        db.update(TABLE_SESSIONS, cv, COL_ID + "=?", new String[]{String.valueOf(sessionId)});
    }

    public List<DataSession> getSessionsForCar(int carId) {
        return getSessionsForCarInRange(carId, 0, Long.MAX_VALUE);
    }

    public List<DataSession> getSessionsForCarInRange(int carId, long fromMs, long toMs) {
        List<DataSession> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String where = COL_CAR_ID + "=? AND " + COL_START + " >= ? AND " + COL_START + " <= ?";
        String[] args = {String.valueOf(carId), String.valueOf(fromMs), String.valueOf(toMs)};
        Cursor c = db.query(TABLE_SESSIONS, null, where, args, null, null, COL_START + " DESC");
        while (c.moveToNext()) list.add(cursorToSession(c));
        c.close();
        return list;
    }

    public void deleteSessionsForCar(int carId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_SESSIONS, COL_CAR_ID + "=?", new String[]{String.valueOf(carId)});
        db.execSQL("UPDATE " + TABLE_CARS + " SET " + COL_TOTAL_BYTES + " = 0 WHERE " + COL_ID + " = " + carId);
    }

    public void deleteSessionsInRange(int carId, long fromMs, long toMs) {
        SQLiteDatabase db = getWritableDatabase();
        String where = COL_CAR_ID + "=? AND " + COL_START + " >= ? AND " + COL_START + " <= ?";
        db.delete(TABLE_SESSIONS, where,
                new String[]{String.valueOf(carId), String.valueOf(fromMs), String.valueOf(toMs)});
        // Recalcular total
        Cursor c = db.rawQuery("SELECT SUM(" + COL_BYTES_DOWN + " + " + COL_BYTES_UP + ") FROM " +
                TABLE_SESSIONS + " WHERE " + COL_CAR_ID + "=" + carId, null);
        long total = 0;
        if (c.moveToFirst()) total = c.getLong(0);
        c.close();
        ContentValues cv = new ContentValues();
        cv.put(COL_TOTAL_BYTES, total);
        db.update(TABLE_CARS, cv, COL_ID + "=?", new String[]{String.valueOf(carId)});
    }

    private DataSession cursorToSession(Cursor c) {
        DataSession s = new DataSession();
        s.setId(c.getInt(c.getColumnIndexOrThrow(COL_ID)));
        s.setCarId(c.getInt(c.getColumnIndexOrThrow(COL_CAR_ID)));
        s.setStartTime(c.getLong(c.getColumnIndexOrThrow(COL_START)));
        s.setEndTime(c.getLong(c.getColumnIndexOrThrow(COL_END)));
        s.setBytesDownloaded(c.getLong(c.getColumnIndexOrThrow(COL_BYTES_DOWN)));
        s.setBytesUploaded(c.getLong(c.getColumnIndexOrThrow(COL_BYTES_UP)));
        return s;
    }
}
