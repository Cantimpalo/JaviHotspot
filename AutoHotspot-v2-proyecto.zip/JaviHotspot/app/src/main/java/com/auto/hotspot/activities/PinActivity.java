package com.auto.hotspot.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.auto.hotspot.R;

public class PinActivity extends AppCompatActivity {

    private EditText etPin;
    private String correctPin;
    private String action;
    private int carId;
    private int attempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);

        correctPin = getIntent().getStringExtra("pin");
        action     = getIntent().getStringExtra("action");
        carId      = getIntent().getIntExtra("car_id", -1);

        etPin = findViewById(R.id.etPinInput);
        Button btnConfirm = findViewById(R.id.btnPinConfirm);
        Button btnCancel  = findViewById(R.id.btnPinCancel);
        TextView tvMsg    = findViewById(R.id.tvPinMessage);

        String actionDesc = "delete_car".equals(action) ? "eliminar este coche" :
                            "delete_total".equals(action) ? "borrar TODOS los datos" :
                            "delete_partial".equals(action) ? "borrar datos por fechas" : "continuar";
        tvMsg.setText("🔐 Introduce el PIN para\n" + actionDesc);

        btnConfirm.setOnClickListener(v -> {
            String entered = etPin.getText().toString().trim();
            if (entered.equals(correctPin)) {
                Intent result = new Intent();
                result.putExtra("action", action);
                result.putExtra("car_id", carId);
                setResult(RESULT_OK, result);
                finish();
            } else {
                attempts++;
                etPin.setText("");
                etPin.setError("PIN incorrecto (" + attempts + "/3)");
                if (attempts >= 3) {
                    Toast.makeText(this, "Demasiados intentos fallidos", Toast.LENGTH_LONG).show();
                    setResult(RESULT_CANCELED);
                    finish();
                }
            }
        });

        btnCancel.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Verificación PIN");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        setResult(RESULT_CANCELED);
        finish();
        return true;
    }
}
