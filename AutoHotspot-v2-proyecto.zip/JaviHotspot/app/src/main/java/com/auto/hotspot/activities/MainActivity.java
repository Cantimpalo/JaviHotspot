package com.auto.hotspot.activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.auto.hotspot.R;
import com.auto.hotspot.database.DatabaseHelper;
import com.auto.hotspot.models.Car;
import com.auto.hotspot.models.DataSession;
import com.auto.hotspot.services.HotspotService;
import com.auto.hotspot.utils.CarBrands;
import com.auto.hotspot.utils.DataUtils;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView tvCarIcon, tvOwnerName, tvCarName, tvStatus, tvSessionData, tvTotalData;
    private View cardConnected, cardIdle;
    private LinearLayout llCarList;
    private Button btnAddCar, btnDataUsage;

    private DatabaseHelper db;
    private Car activeCar = null;

    private final BroadcastReceiver carReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            int carId = intent.getIntExtra(HotspotService.EXTRA_CAR_ID, -1);
            if (HotspotService.ACTION_CAR_CONNECTED.equals(action)) {
                activeCar = db.getCarById(carId);
                showConnectedUI();
            } else if (HotspotService.ACTION_CAR_DISCONNECTED.equals(action)) {
                Car disconnected = db.getCarById(carId);
                showDisconnectedSummary(disconnected);
                activeCar = null;
                showIdleUI();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = DatabaseHelper.getInstance(this);

        tvCarIcon     = findViewById(R.id.tvCarIcon);
        tvOwnerName   = findViewById(R.id.tvOwnerName);
        tvCarName     = findViewById(R.id.tvCarName);
        tvStatus      = findViewById(R.id.tvStatus);
        tvSessionData = findViewById(R.id.tvSessionData);
        tvTotalData   = findViewById(R.id.tvTotalData);
        cardConnected = findViewById(R.id.cardConnected);
        cardIdle      = findViewById(R.id.cardIdle);
        llCarList     = findViewById(R.id.llCarList);
        btnAddCar     = findViewById(R.id.btnAddCar);
        btnDataUsage  = findViewById(R.id.btnDataUsage);

        btnAddCar.setOnClickListener(v ->
                startActivity(new Intent(this, AddCarActivity.class)));

        btnDataUsage.setOnClickListener(v ->
                startActivity(new Intent(this, DataUsageActivity.class)));

        showIdleUI();
        loadCarList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter();
        filter.addAction(HotspotService.ACTION_CAR_CONNECTED);
        filter.addAction(HotspotService.ACTION_CAR_DISCONNECTED);
        registerReceiver(carReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        loadCarList();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { unregisterReceiver(carReceiver); } catch (Exception ignored) {}
    }

    private void loadCarList() {
        llCarList.removeAllViews();
        List<Car> cars = db.getAllCars();

        for (Car car : cars) {
            View item = getLayoutInflater().inflate(R.layout.item_car, llCarList, false);

            TextView icon   = item.findViewById(R.id.tvItemIcon);
            TextView name   = item.findViewById(R.id.tvItemName);
            TextView sub    = item.findViewById(R.id.tvItemSub);
            TextView data   = item.findViewById(R.id.tvItemData);
            ImageButton del = item.findViewById(R.id.btnDeleteCar);

            int brandIdx = getBrandIndex(car.getCarBrand());
            icon.setText(brandIdx >= 0 ? CarBrands.BRAND_ICONS[brandIdx] : "🚗");
            name.setText(car.getOwnerName() + " · " + car.getCarBrand() + " " + car.getCarModel());
            sub.setText("BT: " + car.getBluetoothName());
            data.setText("Total: " + DataUtils.formatBytes(car.getTotalBytesUsed()));

            del.setOnClickListener(v -> confirmDeleteCar(car));

            llCarList.addView(item);
        }

        if (cars.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No hay coches configurados.\nPulsa + para añadir uno.");
            empty.setTextColor(0xFF888888);
            empty.setPadding(24, 24, 24, 24);
            empty.setTextSize(14);
            llCarList.addView(empty);
        }
    }

    private void showConnectedUI() {
        if (activeCar == null) return;
        cardConnected.setVisibility(View.VISIBLE);
        cardIdle.setVisibility(View.GONE);

        int idx = getBrandIndex(activeCar.getCarBrand());
        tvCarIcon.setText(idx >= 0 ? CarBrands.BRAND_ICONS[idx] : "🚗");
        tvOwnerName.setText(activeCar.getOwnerName());
        tvCarName.setText(activeCar.getCarBrand() + " " + activeCar.getCarModel());
        tvStatus.setText("🟢 Hotspot activo");
        tvTotalData.setText("Total acumulado: " + DataUtils.formatBytes(activeCar.getTotalBytesUsed()));
    }

    private void showIdleUI() {
        cardConnected.setVisibility(View.GONE);
        cardIdle.setVisibility(View.VISIBLE);
    }

    private void showDisconnectedSummary(Car car) {
        if (car == null) return;

        // Obtener la última sesión
        List<DataSession> sessions = db.getSessionsForCar(car.getId());
        if (sessions.isEmpty()) return;
        DataSession last = sessions.get(0);

        String msg = "🚗  " + car.getCarBrand() + " " + car.getCarModel() + "\n\n" +
                "⏱  Duración:  " + DataUtils.formatDuration(last.getDurationMs()) + "\n" +
                "⬇  Descarga: " + DataUtils.formatBytes(last.getBytesDownloaded()) + "\n" +
                "⬆  Subida:     " + DataUtils.formatBytes(last.getBytesUploaded()) + "\n" +
                "📦  Total sesión: " + DataUtils.formatBytes(last.getTotalBytes()) + "\n\n" +
                "📊  Acumulado total: " + DataUtils.formatBytes(car.getTotalBytesUsed());

        new AlertDialog.Builder(this, R.style.Dialog_Dark)
                .setTitle("Resumen de sesión")
                .setMessage(msg)
                .setPositiveButton("Cerrar", null)
                .setNeutralButton("Ver historial", (d, w) ->
                        startActivity(new Intent(this, DataUsageActivity.class)
                                .putExtra("car_id", car.getId())))
                .show();
    }

    private void confirmDeleteCar(Car car) {
        // Pedir PIN antes de borrar el coche
        Intent i = new Intent(this, PinActivity.class);
        i.putExtra("pin", car.getPin());
        i.putExtra("action", "delete_car");
        i.putExtra("car_id", car.getId());
        startActivityForResult(i, 200);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 200 && res == RESULT_OK) {
            int carId = data.getIntExtra("car_id", -1);
            if (carId > 0) {
                db.deleteCar(carId);
                loadCarList();
                Toast.makeText(this, "Coche eliminado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private int getBrandIndex(String brand) {
        for (int i = 0; i < CarBrands.BRANDS.length; i++) {
            if (CarBrands.BRANDS[i].equals(brand)) return i;
        }
        return -1;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "📊 Uso de datos").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        menu.add(0, 2, 0, "➕ Añadir coche").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) startActivity(new Intent(this, DataUsageActivity.class));
        else if (item.getItemId() == 2) startActivity(new Intent(this, AddCarActivity.class));
        return true;
    }
}
